﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectARK
{
    /// <summary>
    /// Clase base para los animales
    /// </summary>
    abstract class Animal
    {
        protected bool masculino;

        public Animal(bool masculino)
        {
            this.masculino = masculino;
        }

        public virtual void EntrarAlArca(Arca arca)
        {
            arca.RecibirAnimal(this);
        }
    }


    /// <summary>
    /// Subclase de Animal
    /// </summary>
    class Gato : Animal
    {
        private const string SONIDO_MASCULINO    = "Meow";
        private const string SONIDO_FEMENINO     = "Prrrrr...";

        public Gato(bool masculino)
            : base(masculino)
        {

        }

        public override string ToString()
        {
            return (masculino) ? SONIDO_MASCULINO : SONIDO_FEMENINO;
        }
    }

    /// <summary>
    /// Subclase de Animal
    /// </summary>
    class Jirafa : Animal
    {
        public Jirafa(bool masculino)
            : base(masculino)
        {

        }

        public override string ToString()
        {
            return "...";
        }
    }

    /// <summary>
    /// Subclase de Jirafa que modifica su comportamiento.
    /// La hace más chora.
    /// </summary>
    class Yirafa : Jirafa
    {
        public Yirafa(bool masculino)
            : base(masculino)
        {

        }

        public override string ToString()
        {
            return "CREES QUE ES MUY CHISTOSO QUE NO HAGAMOS NINGÚN SONIDO. EL ÚNICO SONIDO QUE TU HARÁS SERÁ EL DE TU ALMA SUPLICANDO PIEDAD Y CLEMENCIA."; 
        }
    }

    /// <summary>
    /// Subclase de Animal
    /// </summary>
    class Perro : Animal
    {
        public Perro(bool masculino)
            : base(masculino)
        {

        }

        public override string ToString()
        {
            return "Guaf!";
        }
    }

    /// <summary>
    /// Subclase de Animal
    /// </summary>
    class Leon : Animal
    {
        public Leon(bool masculino)
            : base(masculino)
        {

        }

        public override string ToString()
        {
            return "Rawr!";
        }
    }

    /// <summary>
    /// Subclase de Animal
    /// </summary>
    class Gallina : Animal
    {
        public Gallina()
            : base(false) // Todas son hembras. O al menos eso tengo entendido.
        {

        }

        public override string ToString()
        {
            return "COOO..COOO...ROO";
        }
    }
}
