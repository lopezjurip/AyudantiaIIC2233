﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectARK
{
    class Bosque
    {
        public const int MAX_NUMERO_GATOS   = 10;
        public const int MAX_NUMERO_JIRAFA  = 4;
        public const int MAX_NUMERO_YIRAFA  = 1;
        public const int MAX_NUMERO_PERRO   = 8;
        public const int MAX_NUMERO_LEON    = 2;
        public const int MAX_NUMERO_GALLINA = 6;

        private Gato[] gatos;
        private Jirafa[] jirafas;
        private Perro[] perros;
        private Leon[] leones;
        private Gallina[] gallinas;

        private Random randomizer; 

        public Bosque()
        {
            randomizer = new Random();
            CrearGatos();
            CrearGallinas();
            CrearJirafas();
            CrearLeones();
            CrearPerros();
        }

        public Animal CapturarAnimal()
        {
            Animal animalEscogido = null;
            do
            {
                Animal[] conjunto;
                switch (randomizer.Next(0, 5))
                {
                    case 0:
                        conjunto = gatos;
                        break;

                    case 1:
                        conjunto = gallinas;
                        break;

                    case 2:
                        conjunto = jirafas;
                        break;

                    case 3:
                        conjunto = leones;
                        break;

                    case 4:
                        conjunto = perros;
                        break;

                    default:
                        conjunto = new Animal[0];
                        break;
                }
                animalEscogido = conjunto[randomizer.Next(0, conjunto.Length)];

            } while (animalEscogido == null);

            return animalEscogido;
        }

        private bool GeneroRandom()
        {
            // Tomemos un entero aleatorio entre 0 <= n < 2
            // Si es 1, entonces diremos que es masculino.
            // Femenino en otro caso.
            int numero = randomizer.Next(0, 2);
            return numero == 1;
        }

        private void CrearGatos()
        {
            gatos = new Gato[MAX_NUMERO_GATOS];
            for (int i = 0; i < MAX_NUMERO_GATOS; i++)
            {
                gatos[i] = new Gato(GeneroRandom());
            }
        }

        private void CrearJirafas()
        {
            jirafas = new Jirafa[MAX_NUMERO_JIRAFA + MAX_NUMERO_YIRAFA];
            for (int i = 0; i < MAX_NUMERO_JIRAFA; i++)
            {
                jirafas[i] = new Jirafa(GeneroRandom());
            }

            for (int i = MAX_NUMERO_JIRAFA; i < jirafas.Length; i++)
            {
                Jirafa yiraWHAT = new Yirafa(GeneroRandom());
                jirafas[i] = yiraWHAT;
            }
        }

        private void CrearPerros()
        {
            perros = new Perro[MAX_NUMERO_PERRO];
            for (int i = 0; i < MAX_NUMERO_PERRO; i++)
            {
                perros[i] = new Perro(GeneroRandom());
            }
        }

        private void CrearLeones()
        {
            leones = new Leon[MAX_NUMERO_LEON];
            for (int i = 0; i < MAX_NUMERO_LEON; i++)
            {
                leones[i] = new Leon(GeneroRandom());
            }
        }

        private void CrearGallinas()
        {
            gallinas = new Gallina[MAX_NUMERO_GALLINA];
            for (int i = 0; i < MAX_NUMERO_GALLINA; i++)
            {
                gallinas[i] = new Gallina();
            }
        }
    }
}
