﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectARK
{
    class Arca
    {
        private List<Animal> animales;

        public Arca()
        {
            animales = new List<Animal>();
        }

        public virtual void RecibirAnimal(Animal animal)
        {
            Console.WriteLine("Ha entrado un " +animal.GetType());
            animales.Add(animal);
        }

        public virtual String GenerarInforme()
        {
            const String separador = "----------------------------------------";
            const String lineBreak = "\n";

            String header = separador + lineBreak + "Actualmente en el Arca hay " + animales.Count + " animales.";
            String body = "";

            foreach (Animal animal in animales)
            {
                body += lineBreak + separador + lineBreak + "Se escuchó un: " + animal.ToString();
            }
            body += lineBreak + separador;

            return header + body;
        }

        public int SacarYirafas()
        {
            List<Yirafa> yirafasEncontradas = new List<Yirafa>();
            foreach(Animal animal in animales)
            {
                if(animal is Yirafa) {
                    Yirafa yirafa = (Yirafa)animal;
                    yirafasEncontradas.Add(yirafa);
                }
            }

            foreach (Yirafa yirafa in yirafasEncontradas)
            {
                Animal y = yirafa;
                animales.Remove(y);
                
                /* Es mejor:
                 * animales.Remove(yirafa);
                 * Pero la intención es mostrar que una yirafa puede ser tratada como una de sus superclases.
                 */ 
            }
            return yirafasEncontradas.Count;
        }

        public List<Animal> Animales
        {
            get { return animales; }
        }
    }
}
