﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * Patricio López - pelopez2@uc.cl
 */
namespace ProjectARK
{
    class Program
    {
        private const string COMANDO_SALIR = "salir";
        private const string COMANDO_INFORME = "informe";
        private const string COMANDO_CAPTURAR = "capturar";
        private const string COMANDO_SACAR_YIRAFAS = "sacar yirafas";

        static void Main(string[] args)
        {
            Arca arca = new Arca();
            Bosque bosque = new Bosque();

            MostrarAyuda();

            String input = LeerInput();

            while (!input.Equals(COMANDO_SALIR))
            {
                if (input.Equals(COMANDO_INFORME))
                {
                    String informe = arca.GenerarInforme();
                    Console.WriteLine(informe);
                }
                else if (input.Equals(COMANDO_CAPTURAR))
                {
                    Animal animal = bosque.CapturarAnimal();
                    animal.EntrarAlArca(arca);
                }
                else if (input.Equals(COMANDO_SACAR_YIRAFAS))
                {
                    int sacadas = arca.SacarYirafas();
                    Console.WriteLine("Se expulsaron " + sacadas + " yirafas.");
                }
                else
                {
                    MostrarAyuda();
                }

                input = LeerInput();
            }
        }

        private static String LeerInput()
        {
            String input = Console.ReadLine();
            return input.ToLower();
        }

        private static void MostrarAyuda()
        {
            Console.WriteLine("Los comandos disponibles son: "
                + "\n " + COMANDO_INFORME
                + "\n " + COMANDO_CAPTURAR
                + "\n " + COMANDO_SACAR_YIRAFAS
                + "\n " + COMANDO_SALIR);
        }
    }
}
